from flask import Flask, request, jsonify
import openai

app = Flask(__name__)
openai.api_key = "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"

@app.route('/ask', methods=['POST'])
def ask():
    q = request.get_json().get("question", "")
    if not q:
        return jsonify(error="No question provided"), 400
    try:
        r = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": q}],
            temperature=0.4
        )
        return jsonify(answer=r.choices[0].message.content)
    except Exception as e:
        return jsonify(error=str(e)), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
